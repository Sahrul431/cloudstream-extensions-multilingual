package com.hexated

import com.lagradost.cloudstream3.extractors.Filesim

class Oppadrama : DramaidProvider() {
    override var mainUrl = "http://185.217.95.30"
    override var name = "Oppadrama"
}