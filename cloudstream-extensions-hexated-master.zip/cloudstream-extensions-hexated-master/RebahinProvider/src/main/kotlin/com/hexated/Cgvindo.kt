package com.hexated

import com.lagradost.cloudstream3.TvType

class Cgvindo : RebahinProvider() {

    override var mainUrl = "http://51.68.185.138/"

    override var name = "Cgvindo"

}
